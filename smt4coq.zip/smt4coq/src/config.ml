let names = [
    ("Ind(Coq.Init.Datatypes.nat,0)", "Int");
    ("Const(Coq.Init.Nat.add)", "+");
    ("Const(Coq.Init.Nat.sub)", "-");
    ("Const(Coq.Init.Nat.mul)", "*");
    ("Const(Coq.Init.Nat.div)", "/");
    ("Const(Coq.Init.Nat.modulo)", "mod");
    ("Const(Coq.Init.Nat.eqb)", "=");
    ("Const(Coq.Init.Nat.leb)", "<=");
    ("Const(Coq.Init.Nat.ltb)", "<");

    ("Ind(Coq.Init.Peano.le,0)", "<=");
    ("Ind(Coq.Init.Peano.lt,0)", "<");
    ("Ind(Coq.Init.Peano.ge,0)", "=>");
    ("Ind(Coq.Init.Peano.gt,0)", ">");

    ("Ind(Coq.Numbers.BinNums.Z,0)", "Int");
    ("Cst(Coq.ZArith.BinInt.Z.le)", "<=");
    ("Cst(Coq.ZArith.BinInt.Z.lt)", "<");
    ("Cst(Coq.ZArith.BinInt.Z.ge)", ">=");
    ("Cst(Coq.ZArith.BinInt.Z.gt)", ">");

    ("Ind(Coq.Init.Datatypes.bool,0)", "Bool");
    ("Constr(Coq.Init.Datatypes.bool,0,2)", "false");
    ("Constr(Coq.Init.Datatypes.bool,0,1)", "true");
    ("Cst(Coq.Init.Datatypes.andb)", "&&");
    ("Cst(Coq.Init.Datatypes.orb)", "or");
    ("Cst(Coq.Init.Datatypes.notb)", "not");
    ("Cst(Coq.Init.Datatypes.negb)", "not");
    ("Cst(Coq.Init.Datatypes.xorb)", "xor");

    ("Cst(Coq.Init.Logic.not)", "not");
    ("Cst(Coq.Init.Logic.or)", "or");
    ("Ind(Coq.Init.Logic.and,0)", "&&");
    ("Ind(Coq.Init.Logic.eq,0)", "=");
    ("Ind(Coq.Init.Logic.False,0)", "false");
    
  
    ("Ind(Top.Make.int,0)", "_ BitVec 32");
    ("Cst(Top.Make.eq)", "=");
    ("Cst(Top.Make.one)", "#x00000001");
    ("Cst(Top.Make.zero)", "#x00000000");
    ("Cst(Top.Make.add)", "bvadd");
    ("Cst(Top.Make.neg)", "bvneg");
    ("Cst(Top.Make.sub)", "bvsub");
    ("Cst(Top.Make.mul)", "bvmul");
    ("Cst(Top.Make.and)", "bvand");
    ("Cst(Top.Make.or)", "bvor");
    ("Cst(Top.Make.xor)", "bvxor");
    ("Cst(Top.Make.not)", "bvnot");
    ("Cst(Coq.Init.Nat.add)", "+");
    ("Cst(Top.Make.mone)", "#xffffffff");
    ("Cst(Top.Make.divs)", "bvsdiv");
    ("Cst(Top.Make.mods)", "bvsmod");
    ("Cst(Top.Make.divu)", "bvudiv");
    ("Cst(Top.Make.modu)", "bvurem");
    ("Cst(Top.Make.zwordsize)", "32");
    ("Cst(Top.Make.repr)", "(_ int2bv 32)")
]

let rec list_to_map l =
  match l with
  | (a, b)::ls -> let t = (list_to_map ls) in Hashtbl.add t a b;t
  | [] -> Hashtbl.create 10
  | _ -> Hashtbl.create 0

let name_map = list_to_map names
