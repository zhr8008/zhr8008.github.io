## How to write a Coq plugin

Several months ago, I was asked to implement a Coq plugin, but I found all tutorials out-dated... So I decided to write a new tutorial for advanced Coq users. At first, you should know a little OCaml, if you have no idea about OCaml, well, please read *Real World Ocaml* (just knowing syntax is enough) and come back. This tutorial is based on Coq 8.5pl2 and I didn't test source with any other version, so please install the appropriate version. For better comprehension, you had better download the source code of Coq 8.5pl2. The source code of this plugin can be downloaded [here](https://github.com/memruo/coq-plugin-example). Now, here we go.

Firstly, let's look at this theorem:

```coq
Theorem trans_imply: forall P1 P2 P3:Prop,
(P1 -> P2) -> (P2 -> P3) -> (P1 -> P3).
Proof.
intros.
apply H0;apply H;apply H1.
Qed.
```

That's so easy to prove, right? Also, I belive you can prove *trans_imply* with n props (n >= 3) like this:

```coq
Theorem trans_imply_n: forall P1 P2 ... Pn:Prop,
(P1 -> P2) -> (P2 -> P3) -> ... -> (Pn-1 -> Pn).
```

We use `intros` first, and then apply from the second last hypothesis to the first one, and finally apply the last hypothesis and so on. But that's so tedious. We need a program to implement this function automatically. Well, after reading this passage, you will get a tactic to do this work.

Let's create an empty directory and create a empty file called "myplugin.ml4" in it. ".ml4" is the file extension for camlp4, which can support syntax extension to OCaml. Fill the file with the following code:

```ocaml
(*i camlp4deps: "grammar/grammar.cma" i*)

DECLARE PLUGIN "myplugin"

TACTIC EXTEND tac_myplugin
| [ "killtrans"] ->
    [ My_prover.prove () ]
END;;
```
The first line is not a comment. It will tell camlp4 this file use the function of syntax extension. The next line names our plugin "myplugin". The rest will generate a tactic called "killtrans". When you use `killtrans`, you call `My_prover.prove ()` function. Any tactic in Coq is an expression with type `tactic` in OCaml. Thus, the type of prove is `unit -> tactic`.

Let's create "My_prover.ml" file. I'll illustrating each line via comments:

```ocaml
(* kernel/term.ml: define Coq terms (term of Calculus of Inductive Constructions
, CiC) and related operations. *)
open Term
(* library/nameops.ml: some operations about names. We only use pr_id. *)
open Nameops

(* Check a term whether is a arrow type. If it's an arrow type, like "P1 -> P2",
   we apply it. Prod means "dependent product", which you can consider as
   "forall ...". In CiC, arrow type is just a particular case of dependent product. *)
let is_prod constr =
  match kind_of_term constr with
  | Prod _ -> true
  | _ -> false

(* Continue applying hypotheses.
Tactics (tactics/tactics.ml) contains many primitive tactics, like "apply",
"intros" and so on.
Tacticals (tactics/tacticals.ml) can combinate the tactics into a new tactic
(like MonadTransformer in Haskell). New is a module in Tacticals, I'll
introduce it later. tclTHEN is a tactical, whose type is "tactic -> tactic -> tactic".
When Coq evaluates "tclTHEN A B", Coq will apply tactic A and B in sequence.
h is a list of hypotheses. In Coq, each hypothesis is a triple, for example,
"H: P1 -> P2" is stored in Coq like this:
  ("H", _, "P1 -> P2").
Be careful, Coq stores hypotheses in a reverse order. If your hypotheses like this:
  H: ...
  H0: ...
  H1: ...
Coq will store them like this:
  [H1; H0; H]. *)
let rec apply_chain h =
  let (id, _, _) = List.hd h in
  let tac = Tactics.apply (Term.mkVar id) in
  let h = List.tl h in
  let rec apply_prod h =
    match h with
    | (id, _, constr)::hs ->
      if is_prod constr
      then Tacticals.New.tclTHEN (Tactics.apply (Term.mkVar id)) (apply_prod hs)
      else tac
    | [] -> tac
  in
  apply_prod h

(* Proofview (proofs/proofview.ml) shows the state of proofs. Goal.nf_enter tell
Coq we will enter a new proof. So we need Tacticals.New.xxx. Goal.hyps is a
function to extract hypotheses from the environment. *)
let prove () =
  Proofview.Goal.nf_enter ( fun gl ->
    Tacticals.New.tclTHEN Tactics.intros
      (Proofview.Goal.nf_enter
        begin
          fun gl ->
          let hyps = Proofview.Goal.hyps gl in
          apply_chain hyps
        end
    )
  )
```

Ok. Let's create another file "myplugin.mllib", filled with

```
My_prover
Myplugin
```

It just pack many object files to a bigger one. Actually, you also can add content of my_prover.ml into myplugin.ml4. If so, we don't need the .mllib file. 

Everything is OK. Let's build it! Run `coq_makefile *.ml4 *.ml *.mllib > Makefile && make && coqide`, input `Declare ML Module "myplugin".` in coqide and kill the *trans_imply*!
